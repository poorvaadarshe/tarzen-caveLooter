package com.tarzen.cavelooter.service;

import com.tarzen.cavelooter.entity.Game;

public interface BarrierService {

	void organizeBarriers(Game game);
}
