package com.tarzen.cavelooter.service;

import com.tarzen.cavelooter.entity.Game;

public interface GameRefereeService {
	public void updateGameOnAction(Game game,int powerToReduce);
}
